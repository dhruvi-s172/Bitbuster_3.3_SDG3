
import React, { useState } from 'react';
import { ChevronLeft, Info, Search, AlertCircle, CheckCircle2 } from 'lucide-react';

const ENTRIES = [
  {
    t: "Melanoma",
    c: "Malignant",
    d: "The most dangerous form of skin cancer. Develops from melanocytes (pigment-producing cells). Often resembles a mole or develops from one.",
    f: ["Irregular border", "Multi-colored", "Rapid growth"]
  },
  {
    t: "Basal Cell Carcinoma (BCC)",
    c: "Malignant",
    d: "The most common form of skin cancer. Usually occurs in sun-exposed areas. Rarely spreads but can be locally destructive.",
    f: ["Pearly or waxy bump", "Flat, flesh-colored lesion", "Bleeding/scabbing sore"]
  },
  {
    t: "Squamous Cell Carcinoma (SCC)",
    c: "Malignant",
    d: "Develops in the squamous cells of the outer skin. More likely to spread than BCC if not treated.",
    f: ["Firm, red nodule", "Crusty, scaly surface", "Flat sore with scaly crust"]
  },
  {
    t: "Seborrheic Keratosis",
    c: "Benign",
    d: "Noncancerous skin growth that can look like a wart or melanoma. Very common as people age.",
    f: ["Waxy appearance", "Pasted-on look", "Brown or black color"]
  },
  {
    t: "Atypical Nevus (Dysplastic Mole)",
    c: "Variable",
    d: "A mole that looks different from a common mole. Often larger with irregular borders. Can increase risk for melanoma.",
    f: ["Asymmetrical", "Varied colors", "Larger than 6mm"]
  }
];

const EncyclopediaView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const filtered = ENTRIES.filter(e => e.t.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="flex flex-col flex-1 bg-white overflow-y-auto">
      <div className="p-6 sticky top-0 bg-white/90 backdrop-blur-md border-b flex items-center gap-4 z-20">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-900 hover:bg-slate-100 rounded-xl transition-all">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase">Encyclopedia</h2>
      </div>

      <div className="p-6 space-y-6 pb-12">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text"
            placeholder="Search diagnostic terms..."
            className="w-full bg-slate-50 border border-slate-100 py-4 pl-12 pr-4 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="space-y-4">
          {filtered.map((entry, i) => (
            <div key={i} className="p-6 rounded-3xl border border-slate-100 bg-white shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-black text-slate-900">{entry.t}</h3>
                <span className={`text-[9px] font-black uppercase px-2 py-1 rounded-lg border ${
                  entry.c === 'Malignant' ? 'bg-red-50 text-red-600 border-red-100' : 
                  entry.c === 'Benign' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-slate-50 text-slate-500 border-slate-100'
                }`}>
                  {entry.c}
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">{entry.d}</p>
              <div className="flex flex-wrap gap-2">
                {entry.f.map((f, j) => (
                  <span key={j} className="text-[10px] font-bold bg-slate-50 text-slate-600 px-3 py-1 rounded-full border border-slate-100">
                    {f}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 bg-slate-900 rounded-[2rem] text-white">
           <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-blue-400" />
              <h4 className="font-black text-[10px] uppercase tracking-widest">Clinical Note</h4>
           </div>
           <p className="text-xs text-slate-400 leading-relaxed">
             Visually similar lesions can have vastly different diagnostic outcomes. AI assessment is a screening tool; biopsy is the definitive standard for diagnosis.
           </p>
        </div>
      </div>
    </div>
  );
};

export default EncyclopediaView;
