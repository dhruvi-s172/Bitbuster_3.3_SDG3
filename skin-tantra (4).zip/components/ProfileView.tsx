
import React, { useState } from 'react';
import { User, Language } from '../types';
import { translations } from '../translations';
import { 
  ChevronLeft, LogOut, Bell, Shield, 
  Trash2, Info, ChevronRight, Moon, Sun, 
  Fingerprint, Database, Ruler, FlaskConical,
  Activity
} from 'lucide-react';

interface ProfileViewProps {
  user: User;
  onLogout: () => void;
  onBack: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  language: Language;
  onSetLanguage: (lang: Language) => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ user, onLogout, onBack, isDark, onToggleTheme, language, onSetLanguage }) => {
  const t = translations[language];
  
  // Local setting states (simulated)
  const [reminders, setReminders] = useState(true);
  const [sunAlerts, setSunAlerts] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [researchMode, setResearchMode] = useState(true);
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');

  const handleClearHistory = () => {
    if (confirm(t.clearWarning)) {
      localStorage.removeItem('skinscan_history');
      window.location.reload(); // Quick way to reset app state
    }
  };

  const SettingRow = ({ icon: Icon, label, value, onToggle, color = "text-blue-500" }: any) => (
    <div className="w-full p-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center ${color}`}>
          <Icon size={18} />
        </div>
        <span className={`font-bold text-sm ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{label}</span>
      </div>
      <button 
        onClick={onToggle}
        className={`relative w-11 h-6 rounded-full transition-colors duration-200 focus:outline-none ${value ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-700'}`}
      >
        <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform duration-200 ${value ? 'translate-x-5' : 'translate-x-0'}`} />
      </button>
    </div>
  );

  return (
    <div className={`flex flex-col flex-1 ${isDark ? 'bg-slate-950 text-white' : 'bg-[#F8FAFC] text-slate-900'} animate-in slide-in-from-bottom duration-400`}>
      <div className={`p-6 sticky top-0 ${isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white/90 border-b'} backdrop-blur-md flex items-center justify-between z-30`}>
        <button onClick={onBack} className={`p-2 -ml-2 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
          <ChevronLeft size={24} />
        </button>
        <h2 className={`text-xl font-black tracking-tight uppercase ${isDark ? 'text-white' : 'text-slate-900'}`}>{t.settings}</h2>
        <div className="w-8"></div>
      </div>

      <div className="p-6 space-y-8 pb-32 overflow-y-auto">
        {/* Profile Card */}
        <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} p-8 rounded-[2.5rem] border shadow-sm flex flex-col items-center text-center`}>
          <div className="relative mb-6">
            <div className={`w-24 h-24 rounded-[2rem] border-4 ${isDark ? 'border-slate-800' : 'border-slate-50'} shadow-2xl overflow-hidden`}>
              {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" alt="User Avatar" /> : <div className="w-full h-full bg-slate-900 flex items-center justify-center text-white text-3xl font-black">{user.name[0]}</div>}
            </div>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-600 rounded-full border-4 border-white dark:border-slate-900 flex items-center justify-center">
              <Activity size={12} className="text-white" />
            </div>
          </div>
          <h3 className={`text-2xl font-black leading-none mb-1 ${isDark ? 'text-white' : 'text-slate-900'}`}>{user.name}</h3>
          <p className="text-slate-400 font-medium text-xs mb-4">{user.email}</p>
          <div className="flex gap-2">
             <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full text-[9px] font-black uppercase tracking-widest text-slate-400">Pro Member</span>
             <span className="px-3 py-1 bg-green-100 dark:bg-green-900/20 rounded-full text-[9px] font-black uppercase tracking-widest text-green-600">ID Verified</span>
          </div>
        </div>

        {/* Language Selection */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.language}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border p-1.5 flex gap-1 shadow-sm`}>
             <button 
                onClick={() => onSetLanguage('en')}
                className={`flex-1 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${language === 'en' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
             >
               English
             </button>
             <button 
                onClick={() => onSetLanguage('hi')}
                className={`flex-1 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${language === 'hi' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
             >
               हिन्दी (Hindi)
             </button>
          </div>
        </div>

        {/* Display & Notifications */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.appearance} & {t.notifications}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border divide-y dark:divide-slate-800 shadow-sm overflow-hidden`}>
            <SettingRow icon={isDark ? Moon : Sun} label={t.darkMode} value={isDark} onToggle={onToggleTheme} color="text-amber-500" />
            <SettingRow icon={Bell} label={t.reminders} value={reminders} onToggle={() => setReminders(!reminders)} color="text-indigo-500" />
            <SettingRow icon={Sun} label={t.sunAlerts} value={sunAlerts} onToggle={() => setSunAlerts(!sunAlerts)} color="text-orange-500" />
          </div>
        </div>

        {/* Privacy & Security */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.privacy}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border divide-y dark:divide-slate-800 shadow-sm overflow-hidden`}>
            <SettingRow icon={Fingerprint} label={t.biometric} value={biometric} onToggle={() => setBiometric(!biometric)} color="text-cyan-500" />
            <SettingRow icon={FlaskConical} label={t.dataSharing} value={researchMode} onToggle={() => setResearchMode(!researchMode)} color="text-purple-500" />
          </div>
        </div>

        {/* Measurements */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.measurements}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border divide-y dark:divide-slate-800 shadow-sm overflow-hidden`}>
            <button 
              onClick={() => setUnit(unit === 'metric' ? 'imperial' : 'metric')}
              className="w-full p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center text-teal-500`}>
                  <Ruler size={18} />
                </div>
                <span className={`font-bold text-sm ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{t.measurements}</span>
              </div>
              <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest bg-blue-50 dark:bg-blue-900/20 px-3 py-1.5 rounded-lg">
                {unit === 'metric' ? t.metric : t.imperial}
              </span>
            </button>
          </div>
        </div>

        {/* Storage Management */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.storage}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border shadow-sm overflow-hidden`}>
            <button 
              onClick={handleClearHistory}
              className="w-full p-5 flex items-center gap-4 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
            >
              <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center`}>
                <Trash2 size={18} />
              </div>
              <span className="font-bold text-sm uppercase tracking-widest">{t.clearRecords}</span>
            </button>
          </div>
        </div>

        {/* App Info */}
        <div className="space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] ml-1">{t.about}</h4>
          <div className={`${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'} rounded-[2rem] border divide-y dark:divide-slate-800 shadow-sm overflow-hidden`}>
            <div className="p-5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center text-slate-400`}>
                  <Info size={18} />
                </div>
                <span className={`font-bold text-sm ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{t.version}</span>
              </div>
              <span className="text-xs font-bold text-slate-400">4.0.1 (ST-ZEN)</span>
            </div>
            <button className="w-full p-5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center text-slate-400`}>
                  <Shield size={18} />
                </div>
                <span className={`font-bold text-sm ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{t.terms}</span>
              </div>
              <ChevronRight size={16} className="text-slate-300" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <div className="pt-4">
          <button 
            onClick={onLogout}
            className={`w-full flex items-center gap-4 p-6 rounded-[2.5rem] border ${isDark ? 'border-red-900/50 bg-red-900/10 text-red-400 hover:bg-red-900/20' : 'border-red-100 text-red-600 bg-red-50/30 hover:bg-red-50'} transition-all shadow-sm active:scale-95`}
          >
            <div className={`w-10 h-10 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-xl shadow-sm flex items-center justify-center`}><LogOut size={18} /></div>
            <span className="font-black text-xs uppercase tracking-[0.2em]">{t.signOut}</span>
          </button>
        </div>

        <p className="text-[10px] text-slate-300 dark:text-slate-700 text-center uppercase tracking-[0.4em] pt-4 font-black">
          Skin Tantra Engine v4.0
        </p>
      </div>
    </div>
  );
};

export default ProfileView;
