
import React from 'react';
import { ChevronLeft, HeartPulse, ShieldCheck, ArrowUpRight, MessageSquare, Video, Clock } from 'lucide-react';

const PARTNERS = [
  {
    name: "DermLink Pro",
    type: "Photo-Based Analysis",
    time: "Results in 24h",
    desc: "Send high-res photos to board-certified dermatologists for expert review.",
    cost: "$59 / consult",
    color: "bg-blue-600"
  },
  {
    name: "SkyMD Health",
    type: "Video Consultation",
    time: "Live in 15 mins",
    desc: "Connect via secure video for a live full-body skin assessment.",
    cost: "Varies w/ Insurance",
    color: "bg-indigo-600"
  },
  {
    name: "FirstDerm Global",
    type: "Anonymous Screening",
    time: "Results in 8h",
    desc: "Highly private screening service focused on early detection.",
    cost: "$29 / scan",
    color: "bg-slate-900"
  }
];

const TelehealthView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="flex flex-col flex-1 bg-[#F8FAFC] dark:bg-slate-950 animate-in fade-in duration-300">
      <div className="p-6 sticky top-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b dark:border-slate-800 flex items-center justify-between z-10">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-600 dark:text-slate-400">
          <ChevronLeft size={24} />
        </button>
        <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Dermal Partners</h2>
        <HeartPulse size={20} className="text-indigo-600" />
      </div>

      <div className="p-6 space-y-8 pb-32">
        <div className="space-y-2">
          <h3 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Escalate Care.</h3>
          <p className="text-slate-400 dark:text-slate-500 text-sm font-medium">Direct connection to board-certified specialists.</p>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {PARTNERS.map((p, i) => (
            <div key={i} className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 p-8 shadow-sm flex flex-col gap-6 group hover:border-indigo-500 transition-colors">
              <div className="flex justify-between items-start">
                <div className={`w-14 h-14 ${p.color} rounded-2xl flex items-center justify-center text-white shadow-xl`}>
                  <ShieldCheck size={28} />
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 tracking-widest">{p.type}</span>
                  <div className="flex items-center gap-1 text-slate-400 dark:text-slate-600 text-[10px] font-bold uppercase tracking-widest mt-1">
                    <Clock size={10} /> {p.time}
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-2xl font-black text-slate-900 dark:text-white mb-2">{p.name}</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed mb-6">{p.desc}</p>
                <div className="flex items-center justify-between pt-6 border-t dark:border-slate-800">
                  <span className="text-sm font-black text-slate-900 dark:text-white">{p.cost}</span>
                  <button className="flex items-center gap-2 bg-slate-900 dark:bg-indigo-600 text-white px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition-all active:scale-95">
                    Consult <ArrowUpRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-slate-50 dark:bg-slate-900 p-8 rounded-[2.5rem] space-y-6">
          <div className="flex items-center gap-3">
            <MessageSquare size={18} className="text-indigo-500" />
            <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Why Telehealth?</h4>
          </div>
          <div className="grid grid-cols-1 gap-4">
             <div className="flex gap-4">
                <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 flex items-center justify-center text-indigo-600"><Video size={16} /></div>
                <div>
                   <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Wait-Free Diagnostics</p>
                   <p className="text-[10px] text-slate-500 dark:text-slate-500">Skip the 3-month wait for in-person dermatology.</p>
                </div>
             </div>
             <div className="flex gap-4">
                <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 flex items-center justify-center text-indigo-600"><ShieldCheck size={16} /></div>
                <div>
                   <p className="text-xs font-bold text-slate-800 dark:text-slate-200">HIPAA Secure</p>
                   <p className="text-[10px] text-slate-500 dark:text-slate-500">Your dermal data is encrypted and clinically handled.</p>
                </div>
             </div>
          </div>
        </div>

        <p className="text-[10px] text-slate-400 dark:text-slate-600 text-center font-medium uppercase tracking-widest leading-relaxed">
           Skin Tantra receives no commission from partners. We facilitate care escalation for user safety.
        </p>
      </div>
    </div>
  );
};

export default TelehealthView;
