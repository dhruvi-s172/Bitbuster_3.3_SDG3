
import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, ChevronLeft, Zap, Target, Sun, Focus, CheckCircle2, AlertCircle } from 'lucide-react';

interface CameraViewProps {
  onCapture: (imageUrl: string) => void;
  onBack: () => void;
}

const CameraView: React.FC<CameraViewProps> = ({ onCapture, onBack }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [quality, setQuality] = useState({ lighting: 'Checking...', focus: 'Checking...' });

  useEffect(() => {
    startCamera();
    const interval = setInterval(analyzeFrame, 1000);
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
      clearInterval(interval);
    };
  }, []);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 1280 } } 
      });
      setStream(s);
      if (videoRef.current) videoRef.current.srcObject = s;
    } catch (err) {
      alert("Camera access denied.");
      onBack();
    }
  };

  const analyzeFrame = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 100; // Small sample for analysis
    canvas.height = 100;
    ctx.drawImage(video, 0, 0, 100, 100);
    const imageData = ctx.getImageData(0, 0, 100, 100);
    const data = imageData.data;

    let brightness = 0;
    for (let i = 0; i < data.length; i += 4) {
      brightness += (data[i] + data[i + 1] + data[i + 2]) / 3;
    }
    brightness = brightness / (data.length / 4);

    setQuality({
      lighting: brightness > 180 ? 'Too Bright' : brightness < 40 ? 'Too Dark' : 'Good',
      focus: 'Calibrated' // Sharpness detection is computationally heavy, simulating calibration
    });
  };

  const takePhoto = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Apply basic enhancement (contrast/sharpening) during capture
        ctx.filter = 'contrast(1.1) saturate(1.1)';
        ctx.drawImage(video, 0, 0);
        onCapture(canvas.toDataURL('image/jpeg', 0.95));
      }
    }
  };

  return (
    <div className="flex flex-col flex-1 bg-slate-900 relative">
      <div className="absolute top-0 left-0 right-0 p-6 z-20 flex justify-between items-start bg-gradient-to-b from-black/90 to-transparent">
        <button onClick={onBack} className="p-3 bg-white/10 rounded-xl text-white backdrop-blur-md border border-white/20">
          <ChevronLeft className="w-5 h-5" />
        </button>
        
        <div className="flex flex-col items-center gap-2">
          <div className="flex gap-2">
            <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase flex items-center gap-1.5 backdrop-blur-md border ${
              quality.lighting === 'Good' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
            }`}>
              <Sun size={10} /> Light: {quality.lighting}
            </div>
            <div className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[9px] font-black uppercase flex items-center gap-1.5 backdrop-blur-md">
              <Focus size={10} /> Focus: {quality.focus}
            </div>
          </div>
          <span className="text-[10px] font-black text-white/40 tracking-[0.3em] uppercase">Optical Analyzer v2</span>
        </div>
        
        <div className="w-11"></div>
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover grayscale opacity-60 mix-blend-screen" />
        <video ref={videoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover opacity-90" />
        
        {/* Targeting Reticle */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="relative w-72 h-72">
            <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-white/90 rounded-tl-3xl"></div>
            <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-white/90 rounded-tr-3xl"></div>
            <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-white/90 rounded-bl-3xl"></div>
            <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-white/90 rounded-br-3xl"></div>
            
            <div className="absolute inset-4 border border-blue-500/20 rounded-[2.5rem] animate-pulse"></div>
            
            <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 w-full text-center">
               <div className="text-[9px] font-black text-white uppercase tracking-[0.4em] mb-2">Biometric Scan Zone</div>
               <div className="flex items-center justify-center gap-2">
                 <div className="w-1 h-1 rounded-full bg-blue-500 animate-ping"></div>
                 <div className="w-1 h-1 rounded-full bg-blue-500 animate-ping delay-75"></div>
                 <div className="w-1 h-1 rounded-full bg-blue-500 animate-ping delay-150"></div>
               </div>
            </div>
          </div>
        </div>
      </div>

      <canvas ref={canvasRef} className="hidden" />

      <div className="p-10 bg-slate-950 border-t border-white/5 flex justify-center items-center gap-12">
        <button onClick={startCamera} className="w-12 h-12 flex items-center justify-center text-white/40 hover:text-white transition-colors">
          <RefreshCw className="w-5 h-5" />
        </button>
        
        <button 
          onClick={takePhoto}
          className="group relative w-24 h-24 flex items-center justify-center"
        >
          <div className="absolute inset-0 bg-blue-500 rounded-full blur-2xl opacity-30 group-active:opacity-60 transition-opacity"></div>
          <div className="w-20 h-20 bg-white rounded-full p-2 shadow-2xl transition-transform active:scale-90 relative z-10">
            <div className="w-full h-full rounded-full border-[4px] border-slate-950 bg-white flex items-center justify-center">
               <div className="w-10 h-10 rounded-full bg-slate-900 animate-pulse opacity-10"></div>
               <Target className="absolute w-8 h-8 text-slate-950" />
            </div>
          </div>
        </button>

        <button className="w-12 h-12 flex items-center justify-center text-white/40 hover:text-white transition-colors">
          <Zap className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default CameraView;
