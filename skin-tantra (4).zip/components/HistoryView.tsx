
import React from 'react';
import { ScanResult, Language } from '../types';
import { translations } from '../translations';
import { ChevronLeft, Calendar, Trash2, Plus, MapPin, ShieldCheck, Clock } from 'lucide-react';

interface HistoryViewProps {
  history: ScanResult[];
  onBack: () => void;
  onSelect: (scan: ScanResult) => void;
  onDelete: (id: string) => void;
  onNewScan: () => void;
  language: Language;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, onBack, onSelect, onDelete, onNewScan, language }) => {
  const t = translations[language];

  // Helper to group history by date
  const groupedHistory = history.reduce((groups: { [key: string]: ScanResult[] }, scan) => {
    const date = new Date(scan.timestamp).toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(scan);
    return groups;
  }, {});

  const dateKeys = Object.keys(groupedHistory);

  return (
    <div className="flex flex-col flex-1 bg-white dark:bg-slate-950 animate-in fade-in duration-300">
      <div className="p-6 sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 -ml-2 text-slate-600 dark:text-slate-400">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">{t.myRecords}</h2>
        </div>
        <button 
          onClick={onNewScan} 
          className="px-4 py-2 rounded-xl bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
        >
          <Plus size={14} /> {t.newScan}
        </button>
      </div>

      <div className="flex-1 pb-32">
        {history.length === 0 ? (
          <div className="py-24 flex flex-col items-center justify-center text-center px-8">
            <div className="w-24 h-24 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] flex items-center justify-center mb-8 text-slate-200 dark:text-slate-700 shadow-inner">
              <Calendar size={48} />
            </div>
            <h3 className="text-xl font-black text-slate-800 dark:text-slate-200 uppercase tracking-tight">{t.noArchive}</h3>
            <p className="text-slate-400 dark:text-slate-500 mt-3 text-sm leading-relaxed max-w-[240px]">
              {t.startJourney}
            </p>
            <button 
              onClick={onNewScan}
              className="mt-8 bg-slate-900 dark:bg-blue-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl active:scale-95 transition-all"
            >
              {t.initiateFirst}
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {dateKeys.map((date) => (
              <div key={date} className="relative">
                {/* Date Section Header */}
                <div className="sticky top-[73px] z-20 bg-slate-50/80 dark:bg-slate-800/80 backdrop-blur-sm px-6 py-3 border-y border-slate-100 dark:border-slate-700">
                  <p className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Calendar size={12} className="text-blue-500" />
                    {date}
                  </p>
                </div>

                {/* Records for this date */}
                <div className="p-4 space-y-3">
                  {groupedHistory[date].map((item) => (
                    <div 
                      key={item.id}
                      onClick={() => onSelect(item)}
                      className="bg-white dark:bg-slate-900 rounded-[2rem] p-4 border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-5 active:scale-[0.98] hover:border-blue-200 dark:hover:border-blue-900 transition-all cursor-pointer group"
                    >
                      {/* Thumbnail */}
                      <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 bg-slate-100 dark:bg-slate-800 shadow-inner relative">
                        <img src={item.imageUrl} alt="Scan" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0 py-1">
                        <div className="flex items-center gap-1.5 text-slate-900 dark:text-white font-black text-sm mb-1 uppercase tracking-tight">
                          <MapPin size={14} className="text-blue-600 dark:text-blue-400" />
                          {item.location}
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-2">
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-md ${
                            item.assessment.riskLevel === 'High' ? 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400' : 
                            item.assessment.riskLevel === 'Moderate' ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400' : 'bg-green-50 text-green-600'
                          }`}>
                            {item.assessment.riskLevel} {t.riskLevel}
                          </span>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1 text-slate-400 dark:text-slate-500 text-[10px] font-bold">
                            <Clock size={10} />
                            {new Date(item.timestamp).toLocaleTimeString(language === 'hi' ? 'hi-IN' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>

                      {/* Delete */}
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          if(confirm(language === 'hi' ? 'क्या आप इस रिकॉर्ड को हटाना चाहते हैं?' : 'Archive permanently?')) onDelete(item.id);
                        }} 
                        className="p-3 text-slate-200 dark:text-slate-800 hover:text-red-500 transition-colors bg-slate-50 dark:bg-slate-800 rounded-xl"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryView;
