
import React, { useState } from 'react';
import { ChevronLeft, Mail, Lock, ShieldCheck, ArrowRight } from 'lucide-react';
import { User } from '../types';

interface LoginViewProps {
  onSuccess: (user: User) => void;
  onSignup: () => void;
  onBack: () => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onSuccess, onSignup, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API delay
    setTimeout(() => {
      const mockUser: User = {
        id: 'user_1',
        name: 'Alex Johnson',
        email: email,
        joinedAt: Date.now(),
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
      };
      
      localStorage.setItem('skinscan_user', JSON.stringify(mockUser));
      onSuccess(mockUser);
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col flex-1 bg-white p-6 animate-in slide-in-from-right duration-300">
      <button onClick={onBack} className="p-2 -ml-2 text-slate-600 self-start mb-12">
        <ChevronLeft size={24} />
      </button>

      <div className="flex-1 flex flex-col">
        <div className="mb-10">
          <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mb-6 shadow-xl">
            <ShieldCheck className="text-white w-10 h-10" />
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight leading-none mb-4">Welcome <br/>Back.</h2>
          <p className="text-slate-400 font-medium">Log in to sync your clinical history securely.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-slate-50 border border-slate-100 h-14 pl-12 pr-4 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center ml-1">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Password</label>
              <button type="button" className="text-[10px] font-black uppercase tracking-widest text-blue-600">Forgot?</button>
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-50 border border-slate-100 h-14 pl-12 pr-4 rounded-2xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all"
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-slate-900 text-white h-16 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl hover:bg-blue-600 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {isSubmitting ? 'Verifying...' : 'Log In'}
            {!isSubmitting && <ArrowRight size={18} />}
          </button>
        </form>

        <div className="mt-12 text-center">
          <p className="text-slate-400 text-xs font-medium">
            Don't have an account? {' '}
            <button onClick={onSignup} className="text-blue-600 font-black uppercase tracking-widest ml-1">Sign Up</button>
          </p>
        </div>
      </div>
      
      <p className="text-[10px] text-slate-300 text-center uppercase tracking-widest mt-8">
        AES-256 End-to-End Encryption
      </p>
    </div>
  );
};

export default LoginView;
