
import React from 'react';
import { ChevronLeft, Info, HelpCircle } from 'lucide-react';

const TYPES = [
  { id: 1, color: "bg-[#F7E2D0]", t: "Type I", d: "Pale white skin, blue/green eyes, red hair.", r: "Always burns, never tans. Extreme risk." },
  { id: 2, color: "bg-[#F2D1B3]", t: "Type II", d: "Fair skin, blue eyes.", r: "Burns easily, tans minimally. High risk." },
  { id: 3, color: "bg-[#E0B892]", t: "Type III", d: "Darker white skin.", r: "Initially burns, then tans. Moderate risk." },
  { id: 4, color: "bg-[#BD8D68]", t: "Type IV", d: "Light brown skin.", r: "Burns minimally, tans easily. Lower risk." },
  { id: 5, color: "bg-[#96633E]", t: "Type V", d: "Brown skin.", r: "Rarely burns, tans darkly. Low but distinct risk." },
  { id: 6, color: "bg-[#4D3126]", t: "Type VI", d: "Dark brown or black skin.", r: "Never burns, tans very darkly. Risk exists (acral melanoma)." }
];

const SkinTypeView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="flex flex-col flex-1 bg-white overflow-y-auto">
      <div className="p-6 sticky top-0 bg-white/90 backdrop-blur-md border-b flex items-center gap-4 z-20">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-900 hover:bg-slate-100 rounded-xl transition-all">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase">Fitzpatrick Scale</h2>
      </div>

      <div className="p-6 space-y-8 pb-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-slate-400">
             <HelpCircle className="w-5 h-5" />
             <h3 className="text-xs font-black uppercase tracking-widest">Identify Your Type</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            The Fitzpatrick Scale is a scientific classification system for skin color and its response to ultraviolet (UV) radiation.
          </p>
        </div>

        <div className="space-y-4">
          {TYPES.map((type) => (
            <div key={type.id} className="p-5 rounded-3xl border border-slate-100 flex gap-5 items-start bg-white shadow-sm">
               <div className={`w-14 h-14 rounded-2xl ${type.color} shadow-inner flex-shrink-0 border-2 border-slate-50`}></div>
               <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <p className="font-black text-slate-900">{type.t}</p>
                    <span className="text-[10px] font-black text-blue-600 uppercase">Scale {type.id}</span>
                  </div>
                  <p className="text-xs font-bold text-slate-700 mb-1">{type.d}</p>
                  <p className="text-[11px] text-slate-400 leading-tight italic">{type.r}</p>
               </div>
            </div>
          ))}
        </div>

        <div className="p-8 rounded-[2.5rem] bg-blue-50 border border-blue-100">
           <h4 className="font-black text-xs text-blue-800 uppercase mb-2 flex items-center gap-2">
             <Info className="w-4 h-4" /> Crucial Consideration
           </h4>
           <p className="text-xs text-blue-700 leading-relaxed font-medium">
             Regardless of skin type, UV damage is cumulative. While lighter skin types are more prone to common skin cancers, darker skin types are at risk for Acral Lentiginous Melanoma (ALM), which occurs in non-sun-exposed areas like palms and soles.
           </p>
        </div>
      </div>
    </div>
  );
};

export default SkinTypeView;
