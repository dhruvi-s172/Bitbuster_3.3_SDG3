
import React from 'react';
import { ChevronLeft, Sun, Umbrella, Wind, Waves, Shield, Calendar } from 'lucide-react';

const SunSafetyView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const hours = [
    { t: "10AM - 4PM", d: "Peak UV Intensity. Avoid direct exposure.", s: "Critical" },
    { t: "8AM - 10AM", d: "Moderate Intensity. Wear SPF 30+.", s: "Moderate" },
    { t: "4PM - 6PM", d: "Low Intensity. Sunscreen still advised.", s: "Low" }
  ];

  return (
    <div className="flex flex-col flex-1 bg-white overflow-y-auto">
      <div className="p-6 sticky top-0 bg-white/90 backdrop-blur-md border-b flex items-center gap-4 z-20">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-900 hover:bg-slate-100 rounded-xl transition-all">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase">Sun Protocol</h2>
      </div>

      <div className="p-6 space-y-8 pb-12">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-8 rounded-[2.5rem] text-white shadow-xl">
           <Sun className="w-10 h-10 text-amber-400 mb-6" />
           <h3 className="text-2xl font-black leading-tight mb-2">Daily Exposure <br/>Management</h3>
           <p className="text-blue-100 text-sm opacity-80">Behavioral defense is your most effective tool against dermal malignancy.</p>
        </div>

        <div className="space-y-6">
          <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">UV Intensity Schedule</h4>
          <div className="space-y-3">
            {hours.map((h, i) => (
              <div key={i} className="flex items-center justify-between p-5 rounded-3xl bg-slate-50 border border-slate-100">
                <div>
                  <p className="font-black text-slate-900 text-sm mb-1">{h.t}</p>
                  <p className="text-xs text-slate-500">{h.d}</p>
                </div>
                <span className={`text-[9px] font-black uppercase px-2 py-1 rounded-lg ${
                  h.s === 'Critical' ? 'bg-red-500 text-white' : 'bg-slate-200 text-slate-600'
                }`}>
                  {h.s}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
           <div className="p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center gap-3">
              <Umbrella className="w-6 h-6 text-blue-500" />
              <p className="text-xs font-bold text-slate-800">Physical <br/>Shade</p>
           </div>
           <div className="p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center gap-3">
              <Shield className="w-6 h-6 text-blue-500" />
              <p className="text-xs font-bold text-slate-800">SPF 30+ <br/>Reapply 2hr</p>
           </div>
           <div className="p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center gap-3">
              <Waves className="w-6 h-6 text-blue-500" />
              <p className="text-xs font-bold text-slate-800">Water <br/>Resistant</p>
           </div>
           <div className="p-6 rounded-[2rem] border border-slate-100 flex flex-col items-center text-center gap-3">
              <Calendar className="w-6 h-6 text-blue-500" />
              <p className="text-xs font-bold text-slate-800">Cloudy Day <br/>Caution</p>
           </div>
        </div>

        <div className="bg-slate-50 p-6 rounded-3xl text-slate-600 text-xs italic leading-relaxed">
          "Sunburns, especially in childhood, significantly increase the risk of melanoma later in life. Consistent protection is non-negotiable."
        </div>
      </div>
    </div>
  );
};

export default SunSafetyView;
