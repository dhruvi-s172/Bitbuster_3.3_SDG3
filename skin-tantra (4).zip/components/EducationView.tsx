
import React from 'react';
import { ChevronLeft, BookOpen, Info, Search, Heart, UserSearch, Camera, Sun, Zap, Target } from 'lucide-react';

interface EducationViewProps {
  onBack: () => void;
  onViewEncyclopedia: () => void;
  onViewSkinType: () => void;
}

const EducationView: React.FC<EducationViewProps> = ({ onBack, onViewEncyclopedia, onViewSkinType }) => {
  return (
    <div className="flex flex-col flex-1 bg-white dark:bg-slate-950 overflow-y-auto">
      <div className="p-6 sticky top-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b dark:border-slate-800 flex items-center gap-4 z-20">
        <button onClick={onBack} className="p-2 -ml-2 text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Resource Hub</h2>
      </div>

      <div className="p-6 space-y-10 pb-24">
        {/* Quick Nav Grid */}
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={onViewEncyclopedia}
            className="p-5 rounded-3xl bg-slate-900 text-white flex flex-col gap-4 text-left shadow-xl shadow-slate-200 dark:shadow-none transition-all hover:scale-[1.02] active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Search className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-blue-400 tracking-widest mb-1">Lexicon</p>
              <p className="font-bold text-sm">Dermal Encyclopedia</p>
            </div>
          </button>
          <button 
            onClick={onViewSkinType}
            className="p-5 rounded-3xl border-2 border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col gap-4 text-left transition-all hover:border-slate-900 dark:hover:border-blue-500 hover:scale-[1.02] active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center">
              <UserSearch className="w-5 h-5 text-slate-900 dark:text-white" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Assessment</p>
              <p className="font-bold text-sm dark:text-white">Fitzpatrick Skin Type</p>
            </div>
          </button>
        </div>

        {/* NEW: Mastering the Scan Guide */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Capture Protocol</h3>
            <Camera className="w-4 h-4 text-blue-500" />
          </div>

          <p className="text-sm font-bold text-slate-900 dark:text-white mb-2">How to get the most accurate AI results:</p>
          
          <div className="grid grid-cols-1 gap-4">
            <div className="flex gap-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
               <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 flex-shrink-0">
                  <Sun size={20} />
               </div>
               <div>
                  <h4 className="text-xs font-black uppercase tracking-tight text-slate-900 dark:text-white mb-1">01. Perfect Lighting</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Use bright, natural daylight. Avoid harsh shadows or camera flash which can wash out details.</p>
               </div>
            </div>

            <div className="flex gap-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
               <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 flex-shrink-0">
                  <Target size={20} />
               </div>
               <div>
                  <h4 className="text-xs font-black uppercase tracking-tight text-slate-900 dark:text-white mb-1">02. Distance & Focus</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Hold the camera 10–15 cm from the skin. Tap the screen to ensure the lesion is sharp and in focus.</p>
               </div>
            </div>

            <div className="flex gap-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
               <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 flex-shrink-0">
                  <Zap size={20} />
               </div>
               <div>
                  <h4 className="text-xs font-black uppercase tracking-tight text-slate-900 dark:text-white mb-1">03. Clean the Lens</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">Always wipe your camera lens with a soft cloth before scanning. Fingerprints create haze that confuses AI.</p>
               </div>
            </div>
          </div>
        </div>

        {/* Proactive Awareness Section */}
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Skin Vigilance</h3>
            <BookOpen className="w-4 h-4 text-slate-200 dark:text-slate-700" />
          </div>
          
          <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
            <p className="text-sm text-slate-700 dark:text-slate-400 leading-relaxed font-medium">
              Regular self-exams are the foundation of early detection. Monitor any new spots, sores that don't heal, or existing moles that change in appearance.
            </p>
          </div>
        </div>

        {/* Educational Cards */}
        <div className="bg-blue-600 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-blue-100 dark:shadow-none relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-3">
              <Heart className="w-4 h-4 text-blue-300 fill-blue-300" />
              <h3 className="text-xs font-black uppercase tracking-widest text-blue-100">Proactive Care</h3>
            </div>
            <p className="text-lg font-bold leading-tight mb-4">Detection is the First Step to Cure.</p>
            <p className="text-sm text-blue-100 leading-relaxed">
              When caught early, most skin cancers have an extremely high survival rate. Regular professional checks combined with AI-assisted tracking can save lives.
            </p>
          </div>
          <div className="absolute top-[-20%] right-[-10%] w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
        </div>

        <div className="p-6 rounded-3xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-3 mb-4">
             <Info className="w-5 h-5 text-slate-400" />
             <h4 className="font-black text-[10px] uppercase tracking-widest text-slate-400">Self-Exam Checklist</h4>
          </div>
          <ul className="space-y-3 text-xs text-slate-600 dark:text-slate-400 font-medium">
             <li className="flex gap-3"><span className="text-blue-500 font-bold">01</span> Use a full-length mirror for front and back.</li>
             <li className="flex gap-3"><span className="text-blue-500 font-bold">02</span> Check underarms, forearms, and palms.</li>
             <li className="flex gap-3"><span className="text-blue-500 font-bold">03</span> Look at legs, between toes, and soles of feet.</li>
             <li className="flex gap-3"><span className="text-blue-500 font-bold">04</span> Examine neck and scalp with a hand mirror.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default EducationView;
