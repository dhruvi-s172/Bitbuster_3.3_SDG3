
import React, { useState } from 'react';
import { ScanResult, ExpertStatus, Language } from '../types';
import { translations } from '../translations';
import { 
  ChevronLeft, Info, AlertTriangle, CheckCircle2, Search, MapPin, 
  Target, ShieldCheck, Microscope, Droplets, User, Sparkles, 
  Loader2, Waves, Eye, Palette, Zap
} from 'lucide-react';

interface ResultViewProps {
  result: ScanResult;
  onClose: () => void;
  onNewScan: () => void;
  onFindClinics: () => void;
  onUpdateStatus?: (id: string, status: ExpertStatus) => void;
  language: Language;
}

const ResultView: React.FC<ResultViewProps> = ({ result, onClose, onNewScan, onFindClinics, onUpdateStatus, language }) => {
  const { assessment } = result;
  const [isVerifying, setIsVerifying] = useState(false);
  const [status, setStatus] = useState<ExpertStatus>(result.expertStatus);
  const t = translations[language];

  const getRiskUI = (level: string) => {
    switch (level.toLowerCase()) {
      case 'high': return { color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-100', icon: <AlertTriangle className="w-5 h-5" /> };
      case 'moderate': return { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', icon: <Info className="w-5 h-5" /> };
      default: return { color: 'text-green-600', bg: 'bg-green-50', border: 'border-green-100', icon: <CheckCircle2 className="w-5 h-5" /> };
    }
  };

  const handleRequestVerification = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStatus('Pending');
      if (onUpdateStatus) onUpdateStatus(result.id, 'Pending');
      alert(language === 'hi' ? "सत्यापन के लिए भेजा गया।" : "Sent for Expert Triage.");
    }, 2000);
  };

  const ui = getRiskUI(assessment.riskLevel);

  return (
    <div className="flex flex-col flex-1 bg-white dark:bg-slate-950 animate-in slide-in-from-right duration-300">
      <div className="p-6 pb-2 flex items-center justify-between border-b dark:border-slate-800">
        <button onClick={onClose} className="p-2 -ml-2 text-slate-600 dark:text-slate-400">
          <ChevronLeft size={24} />
        </button>
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Clinical Analysis Report</span>
          <span className="text-[8px] font-bold text-blue-500 uppercase tracking-tighter">Ref ID: {result.id.toUpperCase()}</span>
        </div>
        <div className="w-10"></div>
      </div>

      <div className="p-6 space-y-8 pb-32">
        {/* Main Image and Risk Card */}
        <div className="relative">
          <div className="aspect-square rounded-[3rem] overflow-hidden shadow-2xl bg-slate-100 dark:bg-slate-900 border-4 border-white dark:border-slate-800 ring-1 ring-slate-100 dark:ring-slate-700">
            <img src={result.imageUrl} alt="Skin lesion" className="w-full h-full object-cover" />
          </div>
          <div className={`absolute -bottom-6 left-1/2 -translate-x-1/2 w-[90%] p-6 rounded-[2rem] ${ui.bg} dark:bg-slate-900 border ${ui.border} dark:border-slate-800 shadow-xl flex items-center gap-5 backdrop-blur-md`}>
             <div className="relative">
                <svg className="w-16 h-16 transform -rotate-90">
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="4" fill="transparent" className="text-slate-200 dark:text-slate-800" />
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="4" fill="transparent" strokeDasharray={175.9} strokeDashoffset={175.9 - (175.9 * assessment.riskScore / 100)} className={ui.color} />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-xs font-black ${ui.color}`}>{assessment.riskScore}%</span>
                </div>
             </div>
             <div>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Malignancy Risk</p>
                <p className={`text-xl font-black ${ui.color} uppercase`}>{assessment.riskLevel}</p>
             </div>
          </div>
        </div>

        {/* Dermal Topology Section */}
        <div className="pt-6 space-y-4">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Dermal Topology</h4>
          <div className="grid grid-cols-2 gap-3">
             <div className="p-5 rounded-[1.75rem] bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex flex-col gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center">
                  <Droplets size={20} />
                </div>
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Skin Type</p>
                  <p className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight">
                    {assessment.skinCharacteristics?.skinType || "Undetermined"}
                  </p>
                </div>
             </div>
             <div className="p-5 rounded-[1.75rem] bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex flex-col gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center">
                  <User size={20} />
                </div>
                <div>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Structure</p>
                  <p className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight">
                    {assessment.skinCharacteristics?.faceShape || "Morphological"}
                  </p>
                </div>
             </div>
          </div>

          {/* New Dermal Insights Section */}
          <div className="mt-4 space-y-3">
            <h5 className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-2">Dermal Insights</h5>
            <div className="grid grid-cols-1 gap-2">
              {assessment.skinCharacteristics?.visualMarkers && (
                <>
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-500 flex items-center justify-center shrink-0">
                      <Palette size={16} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Pigmentation</p>
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{assessment.skinCharacteristics.visualMarkers.pigmentation}</p>
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
                      <Zap size={16} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Vascularity</p>
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{assessment.skinCharacteristics.visualMarkers.vascularity}</p>
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-500 flex items-center justify-center shrink-0">
                      <Waves size={16} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Hydration</p>
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{assessment.skinCharacteristics.visualMarkers.hydration}</p>
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center shrink-0">
                      <Eye size={16} />
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Pore Quality</p>
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{assessment.skinCharacteristics.visualMarkers.pores}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {assessment.skinCharacteristics?.texture && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 flex items-start gap-3">
              <Sparkles size={14} className="text-amber-500 mt-0.5" />
              <p className="text-[11px] font-medium text-slate-600 dark:text-slate-400 italic">"{assessment.skinCharacteristics.texture}"</p>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {assessment.differentialDiagnosis.map((d, i) => (
            <span key={i} className="px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-900 text-[10px] font-black uppercase text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800">
              {d}
            </span>
          ))}
        </div>

        <div className="bg-blue-600 dark:bg-blue-900 p-8 rounded-[2.5rem] text-white flex flex-col gap-6 relative overflow-hidden">
          <div className="relative z-10 flex flex-col gap-4">
            <div className="flex items-center justify-between">
               <div className="flex items-center gap-2">
                 <Microscope size={18} className="text-blue-300" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-blue-100">{t.expertVerification}</span>
               </div>
               <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase bg-white/20`}>
                 {status}
               </span>
            </div>
            
            {status === 'None' && (
              <button 
                onClick={handleRequestVerification}
                disabled={isVerifying}
                className="w-full bg-white text-blue-600 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
              >
                {isVerifying ? <Loader2 className="animate-spin" size={16} /> : <><ShieldCheck size={16} /> {language === 'hi' ? 'विशेषज्ञ सत्यापन का अनुरोध करें' : 'Submit for Expert Review'}</>}
              </button>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="p-8 rounded-[2.5rem] bg-slate-900 dark:bg-slate-900 text-white">
             <div className="flex items-center gap-2 mb-4 text-blue-400">
               <Target size={18} />
               <span className="text-[10px] font-black uppercase tracking-widest">AI Synthesis ({language.toUpperCase()})</span>
             </div>
             <p className="text-lg font-bold leading-tight mb-6">"{assessment.summary}"</p>
             <p className="text-slate-400 text-xs leading-relaxed italic border-t border-white/10 pt-4">
                {assessment.recommendation}
             </p>
          </div>

          <button 
            onClick={onFindClinics}
            className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-3 uppercase tracking-widest text-xs active:scale-[0.98]"
          >
            <Search size={16} />
            {language === 'hi' ? 'विशेषज्ञों को खोजें' : 'Locate Specialists'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultView;
