import React, { useEffect, useState } from 'react';
import { ChevronLeft, MapPin, ExternalLink, Loader2, Star, UserCheck, ShieldCheck, RefreshCw, AlertCircle } from 'lucide-react';
import { findNearbyDermatologists } from '../services/geminiService';
import { GroundingChunk } from '../types';

const ClinicFinderView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [results, setResults] = useState<{ text: string, links: GroundingChunk[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [locationStatus, setLocationStatus] = useState<'requesting' | 'active' | 'denied' | 'timeout'>('requesting');
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);

  const fetchClinics = async (latitude?: number, longitude?: number) => {
    setLoading(true);
    try {
      const data = await findNearbyDermatologists(latitude, longitude);
      setResults(data as { text: string; links: GroundingChunk[] });
    } catch (err) {
      console.error(err);
      const data = await findNearbyDermatologists(); // Fallback without specific coords
      setResults(data as { text: string; links: GroundingChunk[] });
    } finally {
      setLoading(false);
    }
  };

  const handleGetLocation = () => {
    setLocationStatus('requesting');
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocationStatus('active');
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setCoords({ lat, lng });
          fetchClinics(lat, lng);
        },
        (err) => {
          console.warn("Location error:", err);
          setLocationStatus(err.code === 1 ? 'denied' : 'timeout');
          fetchClinics(); // Fallback search
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    } else {
      setLocationStatus('denied');
      fetchClinics();
    }
  };

  useEffect(() => {
    handleGetLocation();
  }, []);

  return (
    <div className="flex flex-col flex-1 bg-[#F8FAFC] dark:bg-slate-950 overflow-y-auto min-h-screen">
      <div className="p-6 sticky top-0 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border-b dark:border-slate-800 flex items-center justify-between z-20">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 -ml-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Specialist Finder</h2>
        </div>
        
        {locationStatus === 'active' ? (
          <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1.5 rounded-full border border-emerald-100 dark:border-emerald-800/50">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[9px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">Local Active</span>
          </div>
        ) : (
          <button onClick={handleGetLocation} className="p-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-all">
            <RefreshCw size={18} />
          </button>
        )}
      </div>

      <div className="p-6 space-y-6 pb-24">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 text-center space-y-6">
            <div className="relative">
              <div className="w-20 h-20 border-4 border-blue-500/20 rounded-full animate-ping absolute"></div>
              <div className="w-20 h-20 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
              <MapPin className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-600 w-8 h-8" />
            </div>
            <div className="space-y-2">
              <p className="text-slate-900 dark:text-white font-black text-lg">Locating Experts...</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm max-w-[240px] mx-auto">
                {locationStatus === 'requesting' ? "Synchronizing with GPS coordinates..." : "Mapping board-certified clinics in your region."}
              </p>
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            {locationStatus !== 'active' && (
              <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 p-4 rounded-2xl flex gap-3 items-center">
                <AlertCircle className="text-amber-600 shrink-0" size={18} />
                <p className="text-[10px] font-bold text-amber-800 dark:text-amber-400 leading-tight">
                  Location services are inactive. Showing general high-rated results. For local results, please enable GPS and <button onClick={handleGetLocation} className="underline font-black">retry</button>.
                </p>
              </div>
            )}

            {/* AI Summary Card */}
            <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-6 opacity-5">
                 <ShieldCheck size={120} />
               </div>
               <div className="relative z-10">
                 <div className="flex items-center gap-2 mb-4 text-emerald-600 dark:text-emerald-400">
                    <UserCheck size={20} />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Clinical Recommendations</span>
                 </div>
                 <p className="text-slate-700 dark:text-slate-300 text-base leading-relaxed font-medium whitespace-pre-wrap">
                    {results?.text}
                 </p>
               </div>
            </div>

            {/* Doctor List */}
            <div className="space-y-4">
              <div className="flex justify-between items-end px-2">
                 <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Nearby Facilities</h3>
                 <span className="text-[8px] font-bold text-blue-500 uppercase bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded-md tracking-tighter">Live Spatial Data</span>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {results?.links && results.links.length > 0 ? (
                  results.links.map((chunk, i) => (chunk.maps && chunk.maps.uri) && (
                    <a 
                      key={i}
                      href={chunk.maps.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 flex items-center gap-5 active:scale-[0.98] transition-all hover:border-blue-400 group relative"
                    >
                      <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                        <MapPin size={28} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-black text-slate-900 dark:text-white text-lg truncate tracking-tight">{chunk.maps.title}</h4>
                        <div className="flex items-center gap-1.5 mt-1">
                           <Star size={12} className="fill-amber-400 text-amber-400" />
                           <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Verified Specialist</span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-2 text-blue-600 dark:text-blue-400 text-[10px] font-black uppercase tracking-widest">
                          Navigate on Maps <ExternalLink size={10} />
                        </div>
                      </div>
                      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                         <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-white">
                           <ChevronLeft size={14} className="rotate-180" />
                         </div>
                      </div>
                    </a>
                  ))
                ) : (
                  <div className="text-center py-12 p-8 bg-slate-50 dark:bg-slate-900/50 rounded-[2rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
                    <p className="text-slate-400 font-bold text-sm">No clinical markers found in immediate radius. Please check your connectivity or location privacy settings.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="p-8 bg-blue-600 dark:bg-blue-900 rounded-[2.5rem] text-white shadow-lg shadow-blue-500/20">
               <div className="flex items-center gap-3 mb-3">
                 <ShieldCheck size={20} className="text-blue-200" />
                 <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80">Safety Protocol</p>
               </div>
               <p className="text-xs font-medium leading-relaxed">
                 Skin Tantra uses localized spatial grounding to connect you with the nearest qualified professionals. Always verify physician credentials and board certification independently before proceeding with treatment.
               </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClinicFinderView;