
import React, { useState } from 'react';
import { ChevronLeft, User, MapPin, ChevronRight, Check } from 'lucide-react';

interface LocationPickerViewProps {
  onSelected: (location: string) => void;
  onBack: () => void;
}

const BODY_PARTS = [
  { name: "Face / Neck", sub: ["Forehead", "Left Cheek", "Right Cheek", "Nose", "Chin", "Left Ear", "Right Ear", "Neck"] },
  { name: "Scalp", sub: [] },
  { name: "Chest / Torso", sub: [] },
  { name: "Back", sub: [] },
  { name: "Left Arm", sub: ["Upper Arm", "Forearm"] },
  { name: "Right Arm", sub: ["Upper Arm", "Forearm"] },
  { name: "Left Hand", sub: [] },
  { name: "Right Hand", sub: [] },
  { name: "Left Leg", sub: ["Thigh", "Shin", "Calf"] },
  { name: "Right Leg", sub: ["Thigh", "Shin", "Calf"] },
  { name: "Left Foot", sub: [] },
  { name: "Right Foot", sub: [] }
];

const LocationPickerView: React.FC<LocationPickerViewProps> = ({ onSelected, onBack }) => {
  const [activeParent, setActiveParent] = useState<string | null>(null);

  const selectedPart = BODY_PARTS.find(p => p.name === activeParent);

  return (
    <div className="flex flex-col flex-1 bg-white animate-in slide-in-from-right duration-300">
      <div className="p-4 flex items-center gap-4 border-b">
        <button onClick={activeParent ? () => setActiveParent(null) : onBack} className="p-2 -ml-2 text-slate-600">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase">
          {activeParent ? activeParent : "Tag Location"}
        </h2>
      </div>
      
      <div className="p-6">
        <div className="bg-blue-50 p-6 rounded-[2rem] mb-8 flex items-center gap-5 border border-blue-100/50">
          <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
            <User className="w-7 h-7" />
          </div>
          <div>
            <p className="font-black text-slate-900 tracking-tight">Anatomical Precision</p>
            <p className="text-xs text-slate-500 font-medium">Specify the exact location for longitudinal tracking.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {!activeParent ? (
            BODY_PARTS.map((part) => (
              <button
                key={part.name}
                onClick={() => part.sub.length > 0 ? setActiveParent(part.name) : onSelected(part.name)}
                className="flex items-center justify-between p-5 rounded-2xl border border-slate-100 hover:border-blue-400 hover:bg-blue-50/50 transition-all text-left group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 group-hover:text-blue-500 group-hover:bg-white transition-colors">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <span className="font-bold text-slate-800">{part.name}</span>
                </div>
                {part.sub.length > 0 ? (
                  <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500" />
                ) : (
                  <Check className="w-4 h-4 text-transparent group-hover:text-blue-200" />
                )}
              </button>
            ))
          ) : (
            <>
              <button
                onClick={() => onSelected(activeParent)}
                className="flex items-center justify-between p-5 rounded-2xl border-2 border-dashed border-blue-200 bg-blue-50/20 text-blue-600 font-black text-xs uppercase tracking-widest mb-4"
              >
                General {activeParent} Area
              </button>
              {selectedPart?.sub.map((sub) => (
                <button
                  key={sub}
                  onClick={() => onSelected(`${activeParent} - ${sub}`)}
                  className="flex items-center justify-between p-5 rounded-2xl border border-slate-100 hover:border-blue-400 hover:bg-blue-50/50 transition-all text-left group"
                >
                  <span className="font-bold text-slate-800">{sub}</span>
                  <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500" />
                </button>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LocationPickerView;
