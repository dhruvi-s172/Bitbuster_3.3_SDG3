
import React, { useState, useEffect } from 'react';
import { Camera, Sun, Info, ChevronRight, Activity, MapPin, HeartPulse, BookOpen, CloudSun, Wind, ShieldCheck, Zap, Search, Clock } from 'lucide-react';
import { ScanResult, User, Language, AppView } from '../types';
import { translations } from '../translations';

interface LandingViewProps {
  onStart: () => void;
  onSunSafety: () => void;
  onDiseaseInfo: () => void;
  onFindClinic: () => void;
  history: ScanResult[];
  onSelectHistory: (scan: ScanResult) => void;
  user: User | null;
  isDark: boolean;
  language: Language;
  onToggleTheme: () => void;
}

const LandingView: React.FC<LandingViewProps> = ({ onStart, onSunSafety, onDiseaseInfo, onFindClinic, history, onSelectHistory, user, isDark, language }) => {
  const t = translations[language];
  const [uvIndex, setUvIndex] = useState<number>(3);
  const [temp, setTemp] = useState<number>(28);
  const [aqi, setAqi] = useState<number>(42);
  const [locationName, setLocationName] = useState<string>('');
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    // Update clock every minute
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const hour = new Date().getHours();
        if (hour >= 11 && hour <= 15) setUvIndex(7);
        else if (hour >= 8 && hour < 11) setUvIndex(4);
        else setUvIndex(1);
        
        setTemp(22 + Math.floor(Math.random() * 8));
        setAqi(30 + Math.floor(Math.random() * 40));
        setLocationName('South Delhi');
      });
    }

    return () => clearInterval(timer);
  }, []);

  const getUvStatus = (uv: number) => {
    if (uv <= 2) return { label: t.uvLow, color: 'text-emerald-500', bg: 'bg-emerald-500/10' };
    if (uv <= 5) return { label: t.uvMod, color: 'text-amber-500', bg: 'bg-amber-500/10' };
    return { label: t.uvHigh, color: 'text-orange-600', bg: 'bg-orange-500/10' };
  };

  const getAqiStatus = (val: number) => {
    if (val <= 50) return { label: t.aqiGood, color: 'text-emerald-500' };
    if (val <= 100) return { label: t.aqiMod, color: 'text-amber-500' };
    return { label: t.aqiPoor, color: 'text-rose-500' };
  };

  const formattedDate = currentTime.toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric'
  });

  const formattedTime = currentTime.toLocaleTimeString(language === 'hi' ? 'hi-IN' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const uvStatus = getUvStatus(uvIndex);
  const aqiStatus = getAqiStatus(aqi);

  return (
    <div className="p-6 space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700 bg-[#F8FAFC] dark:bg-slate-950 min-h-screen">
      
      {/* Premium Command Center Widget */}
      <section className="relative overflow-hidden group">
        <div className="absolute inset-0 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-none transition-all"></div>
        
        <div className="relative p-6 flex flex-col gap-6">
          {/* Header Row */}
          <div className="flex justify-between items-start">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">{t.commandCenter}</span>
              </div>
              <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight leading-none">
                {language === 'hi' ? 'पर्यावरण रिपोर्ट' : 'Environment Report'}
              </h2>
            </div>

            <div className="flex flex-col items-end gap-1.5">
              <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400 font-black text-[11px] uppercase tracking-tighter">
                <Clock size={12} strokeWidth={3} />
                <span>{formattedTime}</span>
              </div>
              <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                {formattedDate}
              </div>
            </div>
          </div>

          {/* Location & AQI Bar */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800/80 px-4 py-2.5 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
            <MapPin size={12} className="text-blue-600" />
            <span className="text-[9px] font-black text-slate-700 dark:text-slate-300 uppercase tracking-widest">
              {locationName || t.fetchingLocation}
            </span>
            <div className="flex-1"></div>
            <div className="flex items-center gap-2">
               <div className={`w-1.5 h-1.5 rounded-full ${aqiStatus.color.replace('text-', 'bg-')}`}></div>
               <span className={`text-[9px] font-black uppercase ${aqiStatus.color}`}>
                 {t.aqi} {aqi} • {aqiStatus.label}
               </span>
            </div>
          </div>

          {/* Environmental Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-[1.75rem] border border-slate-100 dark:border-slate-800 flex items-center gap-3 transition-colors hover:bg-white dark:hover:bg-slate-800/60 group/metric">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-inner ${uvStatus.bg} ${uvStatus.color}`}>
                <Sun size={20} />
              </div>
              <div>
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t.uvIndex}</p>
                <p className="text-xs font-black text-slate-900 dark:text-white">{uvIndex} • <span className="text-[10px] opacity-70">{uvStatus.label}</span></p>
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-[1.75rem] border border-slate-100 dark:border-slate-800 flex items-center gap-3 transition-colors hover:bg-white dark:hover:bg-slate-800/60 group/metric">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-blue-500/10 text-blue-500 shadow-inner">
                <CloudSun size={20} />
              </div>
              <div>
                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t.weather}</p>
                <p className="text-xs font-black text-slate-900 dark:text-white">{temp}°C • <span className="text-[10px] opacity-70">Clear</span></p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Professional Greeting */}
      <section className="px-1">
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-none mb-1">
          {user ? `${language === 'hi' ? 'नमस्ते' : 'Namaste'}, ${user.name.split(' ')[0]}` : t.dashboard}
        </h2>
        <div className="flex items-center gap-2">
          <Activity size={12} className="text-blue-600 animate-pulse" />
          <p className="text-slate-400 dark:text-slate-500 text-[11px] font-black uppercase tracking-widest">{t.holisticPulse} Alpha-4</p>
        </div>
      </section>

      {/* Enhanced Primary Action Button */}
      <button 
        onClick={onStart}
        className="w-full relative group perspective-1000"
      >
        <div className="absolute inset-0 bg-slate-900 dark:bg-blue-700 rounded-[2.5rem] shadow-2xl shadow-blue-500/20 transform group-active:scale-95 transition-all"></div>
        <div className="relative p-10 flex flex-col gap-6 text-left border border-white/10 rounded-[2.5rem] overflow-hidden">
          {/* Animated Glow Background */}
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
          
          <div className="flex justify-between items-start">
            <div className="w-16 h-16 bg-blue-600 dark:bg-slate-900 rounded-[1.25rem] flex items-center justify-center text-white shadow-xl shadow-blue-900/40 ring-4 ring-white/10">
              <Camera size={32} strokeWidth={2.5} />
            </div>
            <div className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-lg border border-white/20">
              <span className="text-[9px] font-black text-white uppercase tracking-widest flex items-center gap-1.5">
                <Zap size={10} className="fill-white" /> AI Ready
              </span>
            </div>
          </div>
          
          <div>
            <h3 className="text-3xl font-black text-white tracking-tighter mb-1">{t.initiateScan}</h3>
            <p className="text-blue-100/60 text-xs font-bold tracking-tight">{t.morphologicalAI}</p>
          </div>
          
          <div className="flex items-center gap-2 text-white/80 text-[10px] font-black uppercase tracking-[0.2em] pt-2">
            {t.secureProtocol} <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </button>

      {/* Quick Action Grid - Professional Cards */}
      <div className="grid grid-cols-2 gap-4">
        <button onClick={onDiseaseInfo} className="bg-white dark:bg-slate-900 p-6 rounded-[2.25rem] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col gap-5 text-left active:scale-95 transition-all hover:border-blue-200 dark:hover:border-blue-900">
          <div className="w-12 h-12 bg-red-50 dark:bg-red-900/20 rounded-2xl flex items-center justify-center text-red-500 shadow-sm">
            <BookOpen size={22} />
          </div>
          <div className="space-y-0.5">
            <p className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">{t.cancerGuide}</p>
            <p className="text-sm font-black text-slate-800 dark:text-slate-200 tracking-tight">{t.diseaseInfo}</p>
          </div>
        </button>
        <button onClick={onFindClinic} className="bg-white dark:bg-slate-900 p-6 rounded-[2.25rem] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col gap-5 text-left active:scale-95 transition-all hover:border-emerald-200 dark:hover:border-emerald-900">
          <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm">
            <Search size={22} />
          </div>
          <div className="space-y-0.5">
            <p className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">{language === 'hi' ? 'विशेषज्ञ' : 'Specialists'}</p>
            <p className="text-sm font-black text-slate-800 dark:text-slate-200 tracking-tight">{language === 'hi' ? 'क्लीनिक खोजें' : 'Find Clinics'}</p>
          </div>
        </button>
      </div>

      {/* Modern Horizontal Scroll Section for Archive */}
      <section className="space-y-4 px-1">
        <div className="flex justify-between items-center">
          <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-[0.2em]">{t.recentArchive}</h4>
          <button onClick={() => {}} className="text-[9px] font-black text-blue-600 uppercase tracking-widest">View All</button>
        </div>
        
        {history.length > 0 ? (
          <div className="flex gap-4 overflow-x-auto pb-4 snap-x hide-scrollbar">
            {history.map((scan) => (
              <div 
                key={scan.id} 
                onClick={() => onSelectHistory(scan)}
                className="flex-shrink-0 w-[80%] snap-center bg-white dark:bg-slate-900 p-4 rounded-[1.75rem] border border-slate-100 dark:border-slate-800 shadow-sm flex items-center gap-4 active:scale-95 transition-all"
              >
                <div className="w-16 h-16 rounded-[1rem] overflow-hidden flex-shrink-0 bg-slate-50 dark:bg-slate-800 border dark:border-slate-700">
                  <img src={scan.imageUrl} className="w-full h-full object-cover" alt="Scan" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-slate-900 dark:text-white font-black text-xs mb-0.5 uppercase tracking-tight">
                    <MapPin size={10} className="text-blue-600" />
                    {scan.location}
                  </div>
                  <p className="text-slate-400 dark:text-slate-500 text-[10px] font-bold uppercase tracking-widest">{t.riskLevel}: {scan.assessment.riskLevel}</p>
                </div>
                <div className={`px-2 py-1 rounded-lg text-[8px] font-black uppercase ${
                  scan.assessment.riskLevel === 'High' ? 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400'
                }`}>
                  {scan.assessment.riskLevel}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-50 dark:bg-slate-900/50 border border-dashed border-slate-200 dark:border-slate-800 p-10 rounded-[2rem] text-center">
            <p className="text-slate-400 dark:text-slate-600 text-[10px] font-black uppercase tracking-[0.2em]">{t.noRecentData}</p>
          </div>
        )}
      </section>

      {/* Holistic Wisdom Quote - Professional Footer */}
      <div className="relative p-10 rounded-[2.5rem] bg-blue-600 dark:bg-indigo-950/40 border dark:border-indigo-900/50 text-white overflow-hidden shadow-xl shadow-blue-500/10">
        <div className="absolute top-0 right-0 p-4 opacity-20">
          <Zap size={48} className="text-white" />
        </div>
        <div className="relative z-10 flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} className="text-blue-200" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-100">{t.skinWisdom}</span>
          </div>
          <p className="text-base font-black leading-tight tracking-tight italic">"{t.wisdomDesc}"</p>
        </div>
        <div className="absolute bottom-[-10%] left-[-10%] w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
};

export default LandingView;
