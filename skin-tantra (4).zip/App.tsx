import React, { useState, useEffect } from 'react';
import { AppView, ScanResult, User, ExpertStatus, Language } from './types';
import LandingView from './components/LandingView';
import DisclaimerView from './components/DisclaimerView';
import CameraView from './components/CameraView';
import ResultView from './components/ResultView';
import HistoryView from './components/HistoryView';
import EducationView from './components/EducationView';
import ClinicFinderView from './components/ClinicFinderView';
import EncyclopediaView from './components/EncyclopediaView';
import SunSafetyView from './components/SunSafetyView';
import SkinTypeView from './components/SkinTypeView';
import LoginView from './components/LoginView';
import SignupView from './components/SignupView';
import ProfileView from './components/ProfileView';
import DiseaseInfoView from './components/DiseaseInfoView';
import { analyzeSkinLesion } from './services/geminiService';
import { translations } from './translations';
import { Cpu, Scan, ShieldCheck, Home, History as HistoryIcon, BookOpen, User as UserIcon, HeartPulse, Moon, Sun, ClipboardList, Languages } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [history, setHistory] = useState<ScanResult[]>([]);
  const [currentScan, setCurrentScan] = useState<ScanResult | null>(null);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isDark, setIsDark] = useState(false);
  const [language, setLanguage] = useState<Language>('en');

  const t = translations[language];

  useEffect(() => {
    const savedUser = localStorage.getItem('skinscan_user');
    if (savedUser) {
      try { setUser(JSON.parse(savedUser)); } catch (e) { console.error(e); }
    }

    const savedHistory = localStorage.getItem('skinscan_history');
    if (savedHistory) {
      try { setHistory(JSON.parse(savedHistory)); } catch (e) { console.error(e); }
    }

    const savedLang = localStorage.getItem('skintantra_lang');
    if (savedLang === 'hi') setLanguage('hi');

    const savedTheme = localStorage.getItem('skintantra_theme');
    if (savedTheme === 'dark') {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => {
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    localStorage.setItem('skintantra_theme', newIsDark ? 'dark' : 'light');
  };

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'hi' : 'en';
    setLanguage(newLang);
    localStorage.setItem('skintantra_lang', newLang);
  };

  const saveToHistory = (scan: ScanResult) => {
    const newHistory = [scan, ...history];
    setHistory(newHistory);
    localStorage.setItem('skinscan_history', JSON.stringify(newHistory));
  };

  const handleUpdateStatus = (id: string, status: ExpertStatus) => {
    const newHistory = history.map(h => h.id === id ? { ...h, expertStatus: status } : h);
    setHistory(newHistory);
    localStorage.setItem('skinscan_history', JSON.stringify(newHistory));
    if (currentScan?.id === id) {
      setCurrentScan({ ...currentScan, expertStatus: status });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('skinscan_user');
    setUser(null);
    setCurrentView(AppView.LANDING);
  };

  const handleCapture = async (imageUrl: string) => {
    setPendingImage(imageUrl);
    setLoading(true);
    setCurrentView(AppView.ANALYZING);
    
    try {
      const assessment = await analyzeSkinLesion(imageUrl, "Skin Scan", language);
      const result: ScanResult = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        imageUrl: imageUrl,
        location: "Skin Scan",
        assessment,
        expertStatus: 'None'
      };
      
      setCurrentScan(result);
      saveToHistory(result);
      setCurrentView(AppView.RESULT);
    } catch (error) {
      alert(error instanceof Error ? error.message : "An error occurred");
      setCurrentView(AppView.CAMERA);
    } finally {
      setLoading(false);
      setPendingImage(null);
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case AppView.LANDING:
        return <LandingView 
          onStart={() => setCurrentView(AppView.DISCLAIMER)} 
          history={history.slice(0, 2)}
          onSelectHistory={(scan) => { setCurrentScan(scan); setCurrentView(AppView.RESULT); }}
          onSunSafety={() => setCurrentView(AppView.SUN_SAFETY)}
          onDiseaseInfo={() => setCurrentView(AppView.DISEASE_INFO)}
          onFindClinic={() => setCurrentView(AppView.MAPS)}
          user={user}
          isDark={isDark}
          language={language}
          onToggleTheme={toggleTheme}
        />;
      case AppView.AUTH_LOGIN:
        return <LoginView 
          onSuccess={(u) => { setUser(u); setCurrentView(AppView.LANDING); }} 
          onSignup={() => setCurrentView(AppView.AUTH_SIGNUP)} 
          onBack={() => setCurrentView(AppView.LANDING)} 
        />;
      case AppView.AUTH_SIGNUP:
        return <SignupView 
          onSuccess={(u) => { setUser(u); setCurrentView(AppView.LANDING); }} 
          onLogin={() => setCurrentView(AppView.AUTH_LOGIN)} 
          onBack={() => setCurrentView(AppView.LANDING)} 
        />;
      case AppView.PROFILE:
        return user ? <ProfileView 
          user={user} 
          onLogout={handleLogout} 
          onBack={() => setCurrentView(AppView.LANDING)} 
          isDark={isDark} 
          onToggleTheme={toggleTheme} 
          language={language}
          onSetLanguage={(l) => { setLanguage(l); localStorage.setItem('skintantra_lang', l); }}
        /> : null;
      case AppView.DISCLAIMER:
        return <DisclaimerView onAccept={() => setCurrentView(AppView.CAMERA)} onBack={() => setCurrentView(AppView.LANDING)} />;
      case AppView.CAMERA:
        return <CameraView onCapture={handleCapture} onBack={() => setCurrentView(AppView.DISCLAIMER)} />;
      case AppView.ANALYZING:
        return (
          <div className={`flex flex-col items-center justify-center min-h-[80vh] p-12 text-center ${isDark ? 'bg-slate-900' : 'bg-white'}`}>
            <div className="relative w-full max-w-[280px]">
              <div className={`relative aspect-square rounded-[3rem] overflow-hidden border-4 ${isDark ? 'border-slate-800' : 'border-slate-50'} mb-12 shadow-2xl`}>
                {pendingImage && <img src={pendingImage} className="w-full h-full object-cover grayscale opacity-30" alt="processing" />}
                <div className="scan-line"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Scan className="w-16 h-16 text-blue-500 opacity-20" />
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-3">
                  <Cpu className="w-5 h-5 text-blue-600 animate-pulse" />
                  <h2 className={`text-xl font-black uppercase tracking-[0.2em] ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {language === 'hi' ? 'एआई सक्रिय है' : 'CNN Engine Active'}
                  </h2>
                </div>
                <p className={`${isDark ? 'text-slate-500' : 'text-slate-400'} text-xs font-medium leading-relaxed`}>
                   {language === 'hi' ? 'विशेषज्ञ विश्लेषण किया जा रहा है...' : 'Classifying dermal markers...'}
                </p>
              </div>
            </div>
          </div>
        );
      case AppView.RESULT:
        return currentScan ? (
          <ResultView 
            result={currentScan} 
            onClose={() => setCurrentView(AppView.HISTORY)} 
            onNewScan={() => setCurrentView(AppView.CAMERA)}
            onFindClinics={() => setCurrentView(AppView.MAPS)}
            onUpdateStatus={handleUpdateStatus}
            language={language}
          />
        ) : null;
      case AppView.HISTORY:
        return <HistoryView 
          history={history} 
          onBack={() => setCurrentView(AppView.LANDING)} 
          onSelect={(scan) => { setCurrentScan(scan); setCurrentView(AppView.RESULT); }}
          onDelete={(id) => {
            const newHistory = history.filter(h => h.id !== id);
            setHistory(newHistory);
            localStorage.setItem('skinscan_history', JSON.stringify(newHistory));
          }}
          onNewScan={() => setCurrentView(AppView.CAMERA)}
          language={language}
        />;
      case AppView.EDUCATION:
        return <EducationView 
          onBack={() => setCurrentView(AppView.LANDING)} 
          onViewEncyclopedia={() => setCurrentView(AppView.ENCYCLOPEDIA)}
          onViewSkinType={() => setCurrentView(AppView.SKIN_TYPE)}
        />;
      case AppView.MAPS:
        return <ClinicFinderView onBack={() => setCurrentView(AppView.LANDING)} />;
      case AppView.ENCYCLOPEDIA:
        return <EncyclopediaView onBack={() => setCurrentView(AppView.EDUCATION)} />;
      case AppView.SUN_SAFETY:
        return <SunSafetyView onBack={() => setCurrentView(AppView.LANDING)} />;
      case AppView.SKIN_TYPE:
        return <SkinTypeView onBack={() => setCurrentView(AppView.EDUCATION)} />;
      case AppView.DISEASE_INFO:
        return <DiseaseInfoView onBack={() => setCurrentView(AppView.LANDING)} />;
      default:
        return null;
    }
  };

  const isWorkflowView = [AppView.CAMERA, AppView.ANALYZING, AppView.DISCLAIMER, AppView.AUTH_LOGIN, AppView.AUTH_SIGNUP].includes(currentView);

  return (
    <div className={`min-h-screen ${isDark ? 'dark bg-slate-950' : 'bg-[#F8FAFC]'}`}>
      <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 flex flex-col font-sans max-w-md mx-auto shadow-2xl relative overflow-hidden ring-1 ring-slate-200 dark:ring-slate-800 transition-colors duration-300">
        {!isWorkflowView && (
          <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl px-6 h-16 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-slate-900 dark:bg-blue-600 rounded-lg flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-black text-slate-900 dark:text-white tracking-tighter uppercase">Skin<span className="text-blue-600 dark:text-blue-400">Tantra</span></span>
            </div>
            <div className="flex items-center gap-2">
               <button 
                onClick={toggleLanguage} 
                className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 active:scale-95 transition-all"
               >
                 <Languages size={18} className="text-indigo-500" />
               </button>
               <button 
                onClick={toggleTheme} 
                className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 active:scale-95 transition-all"
               >
                 {isDark ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} />}
               </button>
               <button 
                onClick={() => user ? setCurrentView(AppView.PROFILE) : setCurrentView(AppView.AUTH_LOGIN)}
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center overflow-hidden border border-slate-200 dark:border-slate-700 active:scale-95 transition-all"
              >
                {user?.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <UserIcon size={18} className="text-slate-600 dark:text-slate-400" />}
              </button>
            </div>
          </header>
        )}

        <main className={`flex-1 flex flex-col overflow-y-auto ${!isWorkflowView ? 'pb-24' : ''}`}>
          {renderContent()}
        </main>

        {!isWorkflowView && (
          <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 px-4 h-20 flex items-center justify-around z-50 transition-colors">
            <button 
              onClick={() => setCurrentView(AppView.LANDING)}
              className={`flex flex-col items-center gap-1 transition-all ${currentView === AppView.LANDING ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}
            >
              <Home size={20} />
              <span className="text-[8px] font-black uppercase tracking-widest">{t.home}</span>
            </button>
            <button 
              onClick={() => setCurrentView(AppView.HISTORY)}
              className={`flex flex-col items-center gap-1 transition-all ${currentView === AppView.HISTORY ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}
            >
              <ClipboardList size={20} />
              <span className="text-[8px] font-black uppercase tracking-widest">{t.records}</span>
            </button>
            <button 
              onClick={() => setCurrentView(AppView.EDUCATION)}
              className={`flex flex-col items-center gap-1 transition-all ${currentView === AppView.EDUCATION ? 'text-blue-600' : 'text-slate-400 dark:text-slate-500'}`}
            >
              <BookOpen size={20} />
              <span className="text-[8px] font-black uppercase tracking-widest">{t.learn}</span>
            </button>
          </nav>
        )}
      </div>
    </div>
  );
};

export default App;