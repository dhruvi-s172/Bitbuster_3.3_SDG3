import { GoogleGenAI, Type } from "@google/genai";
import { ScanResult, Language } from "../types";

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    riskLevel: {
      type: Type.STRING,
      description: "Assessment of risk: Low, Moderate, or High.",
    },
    riskScore: {
      type: Type.NUMBER,
      description: "A numerical risk score from 0 to 100.",
    },
    differentialDiagnosis: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of potential conditions identified.",
    },
    skinCharacteristics: {
      type: Type.OBJECT,
      properties: {
        skinType: { type: Type.STRING, description: "Oily, Dry, Combination, Normal, or Sensitive" },
        faceShape: { type: Type.STRING, description: "Oval, Round, Square, Heart, Diamond, or Oblong. Only if a face is visible." },
        texture: { type: Type.STRING, description: "Description of the skin surface texture." },
        visualMarkers: {
          type: Type.OBJECT,
          properties: {
            pigmentation: { type: Type.STRING, description: "Details on skin tone uniformity and spots." },
            vascularity: { type: Type.STRING, description: "Presence of redness, inflammation, or visible veins." },
            hydration: { type: Type.STRING, description: "Observation of moisture levels (supple vs dehydrated)." },
            pores: { type: Type.STRING, description: "Observation of pore size and clarity." }
          },
          required: ["pigmentation", "vascularity", "hydration", "pores"]
        }
      },
      required: ["skinType", "texture", "visualMarkers"]
    },
    summary: { type: Type.STRING },
    recommendation: { type: Type.STRING },
    qualityCheck: {
      type: Type.OBJECT,
      properties: {
        lighting: { type: Type.STRING },
        focus: { type: Type.STRING },
        contrast: { type: Type.STRING },
      },
      required: ["lighting", "focus", "contrast"]
    }
  },
  required: ["riskLevel", "riskScore", "differentialDiagnosis", "summary", "recommendation", "qualityCheck", "skinCharacteristics"]
};

export const analyzeSkinLesion = async (base64Image: string, locationHint: string, lang: Language = 'en'): Promise<ScanResult['assessment']> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";
  
  const languageInstructions = lang === 'hi' 
    ? "Return the 'summary', 'recommendation', 'texture', and all 'visualMarkers' fields in Hindi language. The rest can be in English." 
    : "Return all fields in English.";

  const prompt = `
    Dermatology Clinical Assessment Protocol v5.0.
    
    TASK:
    1. Perform image quality preprocessing check.
    2. Identify the anatomical body part from visual cues.
    3. Evaluate for: Melanoma, SCC, BCC, and other skin abnormalities.
    4. SKIN TYPE: Determine if the skin appears Oily, Dry, Combination, or Normal.
    5. FACE STRUCTURE: If a face is visible, identify the Face Shape.
    6. VISUAL MARKERS: Extract detailed observations for pigmentation, vascularity, hydration, and pores.
    
    LANGUAGE:
    ${languageInstructions}
    
    IMPORTANT: This is for educational screening. Provide detailed clinical observations based solely on the visual evidence.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(',')[1] || base64Image,
            },
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: ANALYSIS_SCHEMA,
      },
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini analysis error:", error);
    throw new Error("Analysis failed. Please ensure the image is clear and well-lit.");
  }
};

export const findNearbyDermatologists = async (lat?: number, lng?: number) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-2.5-flash"; // Maps grounding is supported in Gemini 2.5 series.
  
  const locationString = lat && lng ? `near coordinates ${lat}, ${lng}` : "near my current location";
  
  const response = await ai.models.generateContent({
    model: model,
    contents: `Find the most highly-rated board-certified dermatologists and specialty skin cancer clinics ${locationString}. 
    Focus on providers specializing in MOHS surgery, melanoma, and advanced dermal screenings. 
    Provide a professional summary of why these specific clinics are recommended.`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: lat && lng ? { latitude: lat, longitude: lng } : undefined
        }
      }
    },
  });

  return {
    text: response.text,
    links: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};