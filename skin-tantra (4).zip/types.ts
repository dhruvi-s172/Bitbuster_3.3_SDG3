export enum AppView {
  LANDING = 'LANDING',
  DISCLAIMER = 'DISCLAIMER',
  CAMERA = 'CAMERA',
  ANALYZING = 'ANALYZING',
  RESULT = 'RESULT',
  HISTORY = 'HISTORY',
  EDUCATION = 'EDUCATION',
  MAPS = 'MAPS',
  ENCYCLOPEDIA = 'ENCYCLOPEDIA',
  SUN_SAFETY = 'SUN_SAFETY',
  SKIN_TYPE = 'SKIN_TYPE',
  AUTH_LOGIN = 'AUTH_LOGIN',
  AUTH_SIGNUP = 'AUTH_SIGNUP',
  PROFILE = 'PROFILE',
  DISEASE_INFO = 'DISEASE_INFO'
}

export type Language = 'en' | 'hi';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  joinedAt: number;
}

export type ExpertStatus = 'None' | 'Pending' | 'Urgent' | 'Visit' | 'Show';

export interface ScanResult {
  id: string;
  timestamp: number;
  imageUrl: string;
  location: string;
  expertStatus: ExpertStatus;
  assessment: {
    riskLevel: 'Low' | 'Moderate' | 'High';
    riskScore: number; // 0-100
    differentialDiagnosis: string[]; 
    skinCharacteristics?: {
      skinType: 'Oily' | 'Dry' | 'Combination' | 'Normal' | 'Sensitive';
      faceShape?: 'Oval' | 'Round' | 'Square' | 'Heart' | 'Diamond' | 'Oblong';
      texture: string;
      visualMarkers?: {
        pigmentation: string;
        vascularity: string;
        hydration: string;
        pores: string;
      };
    };
    summary: string;
    recommendation: string;
    qualityCheck: {
      lighting: 'Poor' | 'Fair' | 'Good';
      focus: 'Blurry' | 'Sharp';
      contrast: 'Low' | 'High';
    };
  };
}

export enum Type {
  STRING = 'STRING',
  NUMBER = 'NUMBER',
  BOOLEAN = 'BOOLEAN',
  ARRAY = 'ARRAY',
  OBJECT = 'OBJECT',
}

export interface GroundingChunk {
  maps?: {
    uri?: string;
    title?: string;
  };
  web?: {
    uri?: string;
    title?: string;
  };
}